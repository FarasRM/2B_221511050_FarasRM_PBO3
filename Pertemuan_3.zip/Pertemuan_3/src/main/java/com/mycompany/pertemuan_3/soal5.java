/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pertemuan_3;

import java.util.Scanner;
/**
 *
 * @author acer
 */
public class soal5 {
    public static void main(String[] args) {
       
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Masukkan nomor plat mobil: ");
        
        String [] plat = new String [4];

        for (int i = 0; i<4; i++){
            plat[i] = sc.next ();
        }
        
        String gabungplat = String.join("", plat);
                long angka = Long.parseLong(gabungplat);
                long hasil = (angka - 999999)%5;
                
        if(hasil != 0){
            System.out.println("berhenti");
        }else{
            System.out.println("jalan");
        }
    }
}
