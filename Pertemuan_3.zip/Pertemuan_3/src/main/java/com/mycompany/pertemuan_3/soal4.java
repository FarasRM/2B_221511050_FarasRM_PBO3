/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pertemuan_3;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class soal4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Masukkan jumlah penjualan bulan ini: ");
        // Gaji pokok bulanan
        int gajiPokok = 500000;

        // Harga setiap item
        int hargaItem = 50000;

        // Membaca jumlah penjualan bulan ini
        int jumlahPenjualan = input.nextInt();

        // Inisialisasi variabel bonus
        int bonus = 0;

        if (jumlahPenjualan >= 40 && jumlahPenjualan <= 80) {
            // Bonus 25% jika penjualan minimal 40 item
            bonus = (int) (0.25 * jumlahPenjualan * hargaItem);
        } else if (jumlahPenjualan > 80) {
            // Bonus 35% jika penjualan di atas 80 item
            bonus = (int) (0.35 * jumlahPenjualan * hargaItem);
        } else if (jumlahPenjualan < 15) {
            // Denda pemotongan 15% jika penjualan kurang dari 15 item
            bonus = (int) (-0.15 * (15 - jumlahPenjualan) * hargaItem);
        } else {
            // Bonus 10% untuk penjualan di antara 15 hingga 39 item
            bonus = (int) (0.10 * jumlahPenjualan * hargaItem);
        }

        // Menghitung total gaji
        int totalGaji = gajiPokok + bonus;

        // Menampilkan gaji yang diterima
        System.out.println(totalGaji);

        input.close();
    }
}
