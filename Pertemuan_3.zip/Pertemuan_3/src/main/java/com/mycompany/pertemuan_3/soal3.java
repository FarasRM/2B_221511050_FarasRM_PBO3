/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pertemuan_3;

import java.util.Scanner;

/**
 *
 * @author acer
 */
public class soal3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan angka: ");
        // Baca input
        int A = scanner.nextInt();
        String operator = scanner.next();
        int B = scanner.nextInt();

        // Lakukan operasi sesuai operator
        int result = 0;
        switch (operator) {
            case "+":
                result = A + B;
                break;
            case "-":
                result = A - B;
                break;
            case "*":
                result = A * B;
                break;
            case "/":
                result = A / B;
                break;
            case "%":
                result = A % B;
                break;
            default:
                System.out.println("Operator tidak valid");
                return;
        }

        // Cetak hasil operasi
        System.out.println(result);

        scanner.close();
    }
    }
