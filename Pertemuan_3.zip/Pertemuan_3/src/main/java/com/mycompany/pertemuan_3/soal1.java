/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pertemuan_3;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author acer
 */
public class soal1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Masukkan sebuah string:");
        String input = scanner.nextLine();
        
        // Gunakan regular expression untuk menemukan token
        Pattern pattern = Pattern.compile("[A-Za-z]+");
        Matcher matcher = pattern.matcher(input);
        
        int tokenCount = 0;
        
        // Cari dan cetak token
        while (matcher.find()) {
            String token = matcher.group();
            System.out.println(token);
            tokenCount++;
        }
        
        // Cetak jumlah total token
        System.out.println("Jumlah token: " + tokenCount);
    }
}

