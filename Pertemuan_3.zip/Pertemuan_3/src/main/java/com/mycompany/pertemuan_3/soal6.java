/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pertemuan_3;

import java.util.*;
import java.math.BigInteger;

/**
 *
 * @author acer
 */
public class soal6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Membaca dua angka sebagai input
        String a = input.nextLine();
        String b = input.nextLine();

        // Membuat objek BigInteger untuk a dan b
        BigInteger num1 = new BigInteger(a);
        BigInteger num2 = new BigInteger(b);

        // Menjumlahkan a dan b
        BigInteger sum = num1.add(num2);

        // Mengalikan a dan b
        BigInteger product = num1.multiply(num2);

        // Menampilkan hasil penjumlahan dan perkalian
        System.out.println(sum.toString());
        System.out.println(product.toString());

        input.close();
    }
}
